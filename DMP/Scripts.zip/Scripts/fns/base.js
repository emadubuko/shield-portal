﻿function baseUrl() {
    return "/api/";
}