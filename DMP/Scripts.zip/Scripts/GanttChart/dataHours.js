[{ "name": "Task#1",
  "desc": "",
  "values": [
            {"from":  "/Date(1296547200000)/", "to": "/Date(1296554400000)/", "desc": "<b>Task #</b>1<br><b>Data</b>: [2011-02-01 08:00:00 - 2011-02-01 10:00:00] ", "customClass": "ganttRed", "label": "Task #1"},
            {"from":  "/Date(1296637200000)/", "to": "/Date(1296649800000)/", "desc": "<b>Task #</b>1<br><b>Data</b>: [2011-02-02 09:00:00 - 2011-02-02 12:30:00] ", "customClass": "ganttOrange", "label": "Task #1"}
  ]
},
{ "name": "Task#2",
  "desc": "",
  "values": [
            {"from":  "/Date(1296554400000)/", "to": "/Date(1296568800000)/", "desc": "<b>Task #</b>2<br><b>Data</b>: [2011-02-01 10:00:00 - 2011-02-01 14:00:00] ", "customClass": "ganttRed", "label": "Task #2"},
            {"from":  "/Date(1296653400000)/", "to": "/Date(1296658800000)/", "desc": "<b>Task #</b>2<br><b>Data</b>: [2011-02-02 13:30:00 - 2011-02-02 15:00:00] ", "customClass": "ganttGreen"}
  ]
},
{ "name": "Task#3",
  "desc": "",
  "values": [
            {"from":  "/Date(1296574200000)/", "to": "/Date(1296576000000)/", "desc": "<b>Task #</b>3<br><b>Data</b>: [2011-02-01 15:30:00 - 2011-02-01 16:00:00] "},
            {"from":  "/Date(1296655200000)/", "to": "/Date(1296662400000)/", "desc": "<b>Task #</b>3<br><b>Data</b>: [2011-02-02 14:00:00 - 2011-02-02 16:00:00] ", "customClass": "ganttOrange"}
  ]
},
{ "name": "Task#4",
  "desc": "",
  "values": [
            {"from":  "/Date(1296633600000)/", "to": "/Date(1296646200000)/", "desc": "<b>Task #</b>4<br><b>Data</b>: [2011-02-02 08:00:00 - 2011-02-02 11:30:00] ", "label": "Task #4"},
            {"from":  "/Date(1296720000000)/", "to": "/Date(1296730800000)/", "desc": "<b>Task #</b>4<br><b>Data</b>: [2011-02-03 08:00:00 - 2011-02-03 11:00:00] ", "customClass": "ganttGreen"}
  ]
},
{ "name": "Task#5",
  "desc": "",
  "values": [
            {"from":  "/Date(1296646200000)/", "to": "/Date(1296651600000)/", "desc": "<b>Task #</b>5<br><b>Data</b>: [2011-02-02 11:30:00 - 2011-02-02 13:00:00] ", "label": "Task #5"},
            {"from":  "/Date(1296727200000)/", "to": "/Date(1296741600000)/", "desc": "<b>Task #</b>5<br><b>Data</b>: [2011-02-03 10:00:00 - 2011-02-03 14:00:00] ", "customClass": "ganttRed", "label": "Task #5"}
  ]
},
{ "name": "Task#6",
  "desc": "",
  "values": [
            {"from":  "/Date(1296651600000)/", "to": "/Date(1296662400000)/", "desc": "<b>Task #</b>6<br><b>Data</b>: [2011-02-02 13:00:00 - 2011-02-02 16:00:00] ", "customClass": "ganttGreen"},
            {"from":  "/Date(1296716400000)/", "to": "/Date(1296725400000)/", "desc": "<b>Task #</b>6<br><b>Data</b>: [2011-02-03 07:00:00 - 2011-02-03 09:30:00] ", "customClass": "ganttOrange"}
  ]
},
{ "name": "Task#7",
  "desc": "",
  "values": [
            {"from":  "/Date(1296662400000)/", "to": "/Date(1296669600000)/", "desc": "<b>Task #</b>7<br><b>Data</b>: [2011-02-02 16:00:00 - 2011-02-02 18:00:00] ", "label": "Task #7"},
            {"from":  "/Date(1296748800000)/", "to": "/Date(1296756000000)/", "desc": "<b>Task #</b>7<br><b>Data</b>: [2011-02-03 16:00:00 - 2011-02-03 18:00:00] ", "customClass": "ganttGreen", "label": "Task #7"}
  ]
},
{ "name": "Task#8",
  "desc": "",
  "values": [
            {"from":  "/Date(1296720000000)/", "to": "/Date(1296734400000)/", "desc": "<b>Task #</b>8<br><b>Data</b>: [2011-02-03 08:00:00 - 2011-02-03 12:00:00] ", "customClass": "ganttRed", "label": "Task #8"}
  ]
},
{ "name": "Task#9",
  "desc": "",
  "values": [
            {"from":  "/Date(1296660600000)/", "to": "/Date(1296667800000)/", "desc": "<b>Task #</b>9<br><b>Data</b>: [2011-02-02 15:30:00 - 2011-02-02 17:30:00] ", "customClass": "ganttOrange"},
            {"from":  "/Date(1296734400000)/", "to": "/Date(1296745200000)/", "desc": "<b>Task #</b>9<br><b>Data</b>: [2011-02-03 12:00:00 - 2011-02-03 15:00:00] ", "customClass": "ganttRed"}
  ]
},
{ "name": "Task#10",
  "desc": "",
  "values": [
            {"from":  "/Date(1296745200000)/", "to": "/Date(1296752400000)/", "desc": "<b>Task #</b>10<br><b>Data</b>: [2011-02-03 15:00:00 - 2011-02-03 17:00:00] "}
  ]
},
{ "name": "Task#11",
  "desc": "",
  "values": [
            {"from":  "/Date(1296547200000)/", "to": "/Date(1296554400000)/", "desc": "<b>Task #</b>11<br><b>Data</b>: [2011-02-01 08:00:00 - 2011-02-01 10:00:00] "},
            {"from":  "/Date(1296660600000)/", "to": "/Date(1296669600000)/", "desc": "<b>Task #</b>11<br><b>Data</b>: [2011-02-02 15:30:00 - 2011-02-02 18:00:00] ", "customClass": "ganttOrange"}
  ]
},
{ "name": "Task#12",
  "desc": "",
  "values": [
            {"from":  "/Date(1296554400000)/", "to": "/Date(1296568800000)/", "desc": "<b>Task #</b>12<br><b>Data</b>: [2011-02-01 10:00:00 - 2011-02-01 14:00:00] ", "customClass": "ganttGreen"},
            {"from":  "/Date(1296658800000)/", "to": "/Date(1296664200000)/", "desc": "<b>Task #</b>12<br><b>Data</b>: [2011-02-02 15:00:00 - 2011-02-02 16:30:00] ", "customClass": "ganttOrange"}
  ]
},
{ "name": "Task#13",
  "desc": "",
  "values": [
            {"from":  "/Date(1296574200000)/", "to": "/Date(1296576000000)/", "desc": "<b>Task #</b>13<br><b>Data</b>: [2011-02-01 15:30:00 - 2011-02-01 16:00:00] "},
            {"from":  "/Date(1296720000000)/", "to": "/Date(1296730800000)/", "desc": "<b>Task #</b>13<br><b>Data</b>: [2011-02-03 08:00:00 - 2011-02-03 11:00:00] ", "customClass": "ganttRed"}
  ]
},
{ "name": "Task#14",
  "desc": "",
  "values": [
            {"from":  "/Date(1296543600000)/", "to": "/Date(1296550800000)/", "desc": "<b>Task #</b>14<br><b>Data</b>: [2011-02-01 07:00:00 - 2011-02-01 09:00:00] ", "customClass": "ganttOrange"},
            {"from":  "/Date(1296633600000)/", "to": "/Date(1296646200000)/", "desc": "<b>Task #</b>14<br><b>Data</b>: [2011-02-02 08:00:00 - 2011-02-02 11:30:00] ", "customClass": "ganttGreen"}
  ]
},
{ "name": "Task#15",
  "desc": "",
  "values": [
            {"from":  "/Date(1296556200000)/", "to": "/Date(1296565200000)/", "desc": "<b>Task #</b>15<br><b>Data</b>: [2011-02-01 10:30:00 - 2011-02-01 13:00:00] ", "label": "Task #15"},
            {"from":  "/Date(1296646200000)/", "to": "/Date(1296651600000)/", "desc": "<b>Task #</b>15<br><b>Data</b>: [2011-02-02 11:30:00 - 2011-02-02 13:00:00] ", "customClass": "ganttOrange", "label": "Task #15"}
  ]
}]