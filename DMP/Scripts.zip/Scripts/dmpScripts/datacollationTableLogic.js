﻿
if (datacollationArrayFromServer !=null && datacollationArrayFromServer.length > 0) {
    var datacollation = {};
    for (var c = 0; c < datacollationArrayFromServer.length; c++) {
        datacollation = datacollationArrayFromServer[c];
        datacollation.Id = c + 1;
        datacollationArray.push(datacollation);
        CreatedatacollationTable(datacollation);
    }
}


$("#adddatacollationbtn").click(function (e) {
    var datacollation = {};
    datacollation["Id"] = datacollationArray.length + 1;
    var dateStringArray = [];
    
    let reportinglevel = '';
    $("#dtReportingLevel option:selected").each(function () {
        reportinglevel += $(this).val() + ',';
    });
    datacollation["ReportingLevel"] = reportinglevel;
    $("#dtReportingLevel").val("");

    var cf = $("#CollationFrequency")[0].value;
    datacollation["CollationFrequency"] = cf;
    $("#CollationFrequency").val("");

    var dtype =  $("#DataType")[0].value;
    datacollation["DataType"] =dtype;
    $("#DataType").val("");
     
    if (dtype != "" && cf != "" && datacollation.ReportingLevel != "") {
        datacollationArray.push(datacollation);
        CreatedatacollationTable(datacollation);
    }    
});

function CreatedatacollationTable(datacollation) {
   
    var datacollationId = "datacollationx" + datacollation.Id;
    var html = '<tr id=' + datacollationId + '>';
    html += '<td>' + datacollation.ReportingLevel + '</td>';
    html += '<td>' + datacollation.DataType + '</td>'; 
    html += '<td>' + datacollation.CollationFrequency + '</td>';     
    if (editMode) {
        html += '<td><input type="button" value="Edit" class="btn btn-info btn-sm btn-outline" onclick="MakeEditable(' + datacollationId + ')"/></td>';
        html += '<td><input type="button" value="Remove" class="btn btn-danger btn-sm btn-outline" onclick="DeleteRow(' + datacollationId + ')"/></td>';
    }
    html += '</tr>';
    $('#datacollationdataTable').append(html);
}